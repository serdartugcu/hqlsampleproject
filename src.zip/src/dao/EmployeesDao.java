package dao;

import model.Employees;
import org.hibernate.Session;
import org.hibernate.query.Query;

import java.util.List;


/**
 * Created by serdartugcu on 31.03.2018.
 */
public class EmployeesDao {
    public Employees getEmployee(Integer empNo) {
        Session session = HibernateUtil.getSession();
        String hql = "from Employees e where e.empNo = :empNo";
        Query query = session.createQuery(hql);
        query.setParameter("empNo", empNo);
        Employees employees = (Employees) query.uniqueResult();
        return employees;
    }

    public List<Employees> getEmployeeList(int min, int max) {
        Session session = HibernateUtil.getSession();
        String hql = "from Employees";
        Query query = session.createQuery(hql);
        query.setFirstResult(min);
        query.setMaxResults(max);
        List<Employees> employeesList = query.list();
        return employeesList;
    }
}

import model.Employees;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;
import service.EmployeesService;

import java.sql.Date;
import java.util.List;
import java.util.Scanner;


/**
 * Created by serdartugcu on 17.03.2018.
 */
public class Main {

    public static void main(String[] args) {
        Scanner reader = new Scanner(System.in);  // Reading from System.in
        int i = 0;
        int rowCount = 10;
        boolean showList = true;
        EmployeesService employeeService = new EmployeesService();

        do {
            if(showList) {
                List<Employees> employeesList = employeeService.getEmployeeList(i*rowCount, rowCount);
                for(Employees employees:employeesList) {
                    System.out.println(employees);
                }
            }
            System.err.println("Please write next for the next page, prev for the previous page, or the empNo to get the Employee");
            System.err.println("Type Q to quit application");
            String input = reader.next();
            if(input.equalsIgnoreCase("next")) {
                i++;
                showList = true;
            }
            else if(input.equalsIgnoreCase("prev")) {
                if(i>0) {
                    i--;
                    showList = true;
                }
                else {
                    System.err.println("You are at the first page");
                    showList = false;
                }
            }
            else if (input.equalsIgnoreCase("Q")) {
                System.out.println("Bye");
                System.exit(0);
            }
            else {
                System.out.println(employeeService.getEmployee(Integer.parseInt(input)));
                showList = false;
            }
        }
        while (true);
    }


    }


package service;

import dao.EmployeesDao;
import model.Employees;

import java.util.List;

/**
 * Created by serdartugcu on 31.03.2018.
 */
public class EmployeesService {
    public Employees getEmployee(Integer empNo) {
        EmployeesDao employeesDao = new EmployeesDao();
        return employeesDao.getEmployee(empNo);
    }

    public List<Employees> getEmployeeList(int min, int max) {
        EmployeesDao employeesDao = new EmployeesDao();
        return employeesDao.getEmployeeList(min, max);
    }
}
